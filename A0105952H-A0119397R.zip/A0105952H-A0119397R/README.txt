CS3245 Homework2

== Files included with this submission ==
dictionary.txt
postings.txt
search.py
index.py

== members and emails ==
A0105952H a0105952@u.nus.edu
A0119397R a0119397@u.nus.edu